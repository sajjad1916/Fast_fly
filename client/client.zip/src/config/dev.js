module.exports = {
    apikey: 'AIzaSyCfzhSh2aCFNXDbpv2QR7-mHtM2vosczV8',
    authdomain: 'reactauth-138db.firebaseapp.com',
    projectId: 'reactauth-138db',
    storageBucket:'reactauth-138db.appspot.com',
    messagingSenderID: '700972913326',
    appID: '1:700972913326:web:9f1f851a18f35e0420133f',
    measurementID: 'G-ZVWXZVWVKF'

}